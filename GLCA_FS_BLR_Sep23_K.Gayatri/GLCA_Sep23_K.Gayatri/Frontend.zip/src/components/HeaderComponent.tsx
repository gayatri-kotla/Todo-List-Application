import React from 'react'

const HeaderComponent = () => {
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <a className="navbar-brand" href='http://localhost:3000'>Todo Management</a>
        </nav>
    )
}

export default HeaderComponent