import React, { useEffect, useState } from 'react'
import { createTodo, getTodo, updateTodo } from '../services/TodoService';
import { useNavigate, useParams } from 'react-router-dom';

const TodoComponent = () => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [completed, setCompleted] = useState(false);
    const navigate = useNavigate();
    const { id } = useParams();

    function saveOrUpdateTodo(e: any) {
        e.preventDefault();
        const newTodo = { title, description, completed };
        if (id) {
            updateTodo(id, newTodo).then((response) => {
                console.log(response.data)
                navigate('/todos')
            })
        } else {
            createTodo(newTodo).then((response) => {
                console.log(response.data)
                navigate('/todos')

            })

        }



    }
    function pageTitle() {
        if (id) {
            return <h2 className='text-center'>Update Todo</h2>
        }
        else {
            return <h2 className='text-center'>Add Todo</h2>
        }
    }
    useEffect(() => {
        if (id) {
            getTodo(id).then((response) => {
                setTitle(response.data.title)
                setDescription(response.data.description)
                setCompleted(response.data.completed)
            })
        }
    }, [id])

    return (
        <div className='container'>
            <br />
            <br />
            <div className='row'>

                <div className='card col-md-6 offset-md-3 offset-md-3'>

                    {pageTitle()}
                    <div className='card-body'>
                        <form>
                            <div className='mb-form-group mb-2'>
                                <label className='form-label'>Todo Title: </label>
                                <input type='text' name='title' className='form-control' placeholder='Enter todo title' value={title} onChange={(e: any) => setTitle(e.target.value)} />
                            </div>
                            <div className='mb-form-group mb-2'>
                                <label className='form-label'>Todo Description: </label>
                                <input type='text' name='description' className='form-control' placeholder='Enter todo decsription' value={description} onChange={(e: any) => setDescription(e.target.value)} />
                            </div>
                            <div className='mb-form-group mb-2'>
                                <label className='form-label'>Todo Completed: </label>
                                <select className='form-control' value={completed.toString()} onChange={(e: any) => setCompleted(e.target.value === "true")}>
                                    <option value="true">Yes</option>
                                    <option value="false">No</option>
                                </select>
                            </div>
                            <button className='btn btn-success' onClick={saveOrUpdateTodo}>Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default TodoComponent