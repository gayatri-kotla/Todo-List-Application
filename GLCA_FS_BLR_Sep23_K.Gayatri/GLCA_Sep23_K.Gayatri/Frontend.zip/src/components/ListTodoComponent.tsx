import React, { useEffect, useState } from 'react'
import { completeTodo, deleteTodo, getAllTodos, incompleteTodo } from '../services/TodoService'
import { useNavigate } from 'react-router-dom';

const ListTodoComponent = () => {
    const [todos, setTodos] = useState<any[]>([]);
    const navigate = useNavigate();
    useEffect(() => {
        allTodos();
    }, [])
    function allTodos() {
        getAllTodos().then((response) => {
            setTodos(response.data);
            console.log(todos)
        })
    }
    function addTodo() {
        navigate('/add-todo')
    }
    function updateTodo(id: any) {
        navigate(`/update-todo/${id}`)
    }
    function markCompleteTodo(id: any) {
        completeTodo(id).then((response) => {
            console.log(response.data)
            allTodos();
        })
    }
    function markIncompleteTodo(id: any) {
        incompleteTodo(id).then((response) => {
            console.log(response.data)
            allTodos();
        })
    }
    function removeTodo(id: any) {
        deleteTodo(id).then((msg) => {

            allTodos();
        }).catch(err => {
            console.log(err);
        })
    }



    return (
        <div className='container'>
            <h2 className='text-center'>List of Todos</h2>
            <button className='btn btn-primary' onClick={addTodo}>Add Todo</button>

            <table className='table table-bordered table-striped'>
                <thead>
                    <tr>

                        <th>Title</th>
                        <th>Description</th>
                        <th>Completed</th>
                        <th>Actions</th>

                    </tr>
                </thead>
                <tbody>
                    {
                        todos.map((todo, index) => {
                            return (
                                <tr key={index}>

                                    <td>{todo.title}</td>
                                    <td>{todo.description}</td>
                                    <td>{todo.completed ? 'YES' : 'NO'}</td>
                                    <td>
                                        <button className='btn btn-info' style={{ marginLeft: '5px ' }} onClick={() => updateTodo(todo.id)}>Update</button>
                                        <button className='btn btn-success' style={{ marginLeft: '5px ' }} onClick={() => markCompleteTodo(todo.id)}>Complete</button>
                                        <button className='btn btn-warning' style={{ marginLeft: '5px ' }} onClick={() => markIncompleteTodo(todo.id)}>Incomplete</button>
                                        <button className='btn btn-danger' style={{ marginLeft: '5px ' }} onClick={() => removeTodo(todo.id)}>Delete</button>
                                    </td>
                                </tr>
                            )

                        })

                    }
                </tbody>

            </table>
        </div >
    )
}

export default ListTodoComponent