import React from 'react';

const FooterComponent = () => {
    return (

        <div className="footer">
            <span>&copy; 2024 Great Learning. All rights reserved.</span>
        </div>

    );
}

export default FooterComponent;
