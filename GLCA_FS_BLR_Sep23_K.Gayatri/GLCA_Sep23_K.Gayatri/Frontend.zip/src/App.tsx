import React from 'react'
import ListTodoComponent from './components/ListTodoComponent'
import HeaderComponent from './components/HeaderComponent'
import { Route, Routes } from 'react-router-dom'
import TodoComponent from './components/TodoComponent'
import FooterComponent from './components/FooterComponent'

const App = () => {
  return <>
    <HeaderComponent />

    <Routes>
      <Route path={'/'} element={<ListTodoComponent />}></Route>
      <Route path={'/todos'} element={<ListTodoComponent />}></Route>
      <Route path={'/add-todo'} element={<TodoComponent />}></Route>
      <Route path={'/update-todo/:id'} element={<TodoComponent />}></Route>
    </Routes>
    <FooterComponent />
  </>
}

export default App